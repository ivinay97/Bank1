import { Transactions } from './transactions';

export class account {
    accnumber: any;
    accholdername: any;
    branch: any;
    phonenumber: any;
    dob: any;
    email: any;
    balance: number;
    amount: number;
    transactions: Transactions[];
    recieverAccNumber: number;
    senderAccNumber: any;
    password: any;
   
    cpassword: string;
    flag:boolean;
}