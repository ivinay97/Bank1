import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent, routes } from './app.component';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { BalanceComponent } from './balance/balance.component';
import { DebitComponent } from './debit/debit.component';
import { CreditComponent } from './credit/credit.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { TransactionComponent } from './transaction/transaction.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { AddcustomerService } from './addcustomer.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { ProfileComponent } from './profile/profile.component';
import { AdminComponent } from './admin/admin.component';
import { UserTransactionsComponent } from './user-transactions/user-transactions.component';




@NgModule({
  declarations: [
    AppComponent,
    AddcustomerComponent,
    BalanceComponent,
    DebitComponent,
    CreditComponent,
    FundtransferComponent,
    TransactionComponent,
    LoginComponent,
    LogoutComponent,
    ChangepasswordComponent,
    ProfileComponent,
    AdminComponent,
    UserTransactionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }