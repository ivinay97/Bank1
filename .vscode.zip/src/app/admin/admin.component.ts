import { Component, OnInit } from '@angular/core';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';
import { Admin } from '../admin';
import { Transactions } from '../transactions';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  admin: Admin = new Admin();
  accounts: account = new account();
  transactions: Transactions = new Transactions();
  account: account = new account();


  constructor(private _service: AddcustomerService) { }

  ngOnInit() {
    this.admin.username = localStorage.getItem("username");
    this._service.getAllUsers().subscribe((data: any) => {
    this.accounts = data
    }, error => console.log(error));
  }

  myFunction() {

    var input;
    input = document.getElementById("myInput");
    var filter = input.value;
    var table = document.getElementById("myTable");
    var tr = table.getElementsByTagName("tr");
    for (var i = 0; i < tr.length; i++) {
      var td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        var txtValue = td.textContent || td.innerText;
        if (txtValue.indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  block(ac: account) {
    this._service.block(ac.accnumber).subscribe((data: any) => {
      this.account = data
      if (this.account.flag) {
        alert("blocked successfully");
        {
          document.getElementById(this.account.accnumber).innerText = "BLOCKED"
        }
      }
      else {
        alert("unblocked unsuccessfully");
        {
          document.getElementById(this.account.accnumber).innerText = "BLOCK"
        }
      }
    }, error => console.log(error));
  }
}