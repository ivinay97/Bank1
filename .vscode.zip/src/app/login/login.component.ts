import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';
import { account } from '../account';
import { Admin }   from '../admin';
import { AddcustomerService } from '../addcustomer.service';
import { AuthguardService } from '../authguard.service';
import { AdminAuthGuardService } from '../admin-auth-guard.service';
import { HttpClientModule, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  account: account = new account();
  admin:Admin=new Admin();
  constructor(private router: Router,
    private loginservice: AddcustomerService,private guard: AuthguardService,private _serviceguard:AdminAuthGuardService) { }
  message: string = "";
  message1: string = "";
  checked=false;
  marked=false;
 
  
  conversionOutput: string;
  ngOnInit() {
  let x = this.guard.isLoggedIn();
  let y= this._serviceguard.isAdmin();
  
  if((x)&&(!y))
  {
    this.router.navigate(['Balance']);
  }
  else if((x)&&(y))
  {
    this.router.navigate(['admin']);
  }
  else
  {
    this.router.navigate(['']);
  }
  }
  check(e){
    this.marked= e.target.checked;
  }
  checkLogin() {
    
   if(!this.marked)
    {
    this.loginservice.getUser(this.account.email, this.account.password).subscribe((data: any) => {
      
     
       this.account=data;
    
  if(!this.account.flag)

   {
      sessionStorage.setItem('isLoggedIn', "true");
      localStorage.setItem('isLoggedIn',"true");
      
   localStorage.setItem('isAdmin',"false");
  
         
    
    
      localStorage.setItem('email1',this.account.accnumber);
      sessionStorage.setItem('acountname', this.account.accholdername);
     localStorage.setItem('acountname', this.account.accholdername);
      localStorage.setItem('branch',this.account.branch);
      localStorage.setItem('email',this.account.email);
      localStorage.setItem('phonenumber',this.account.phonenumber);
      localStorage.setItem('dob',this.account.dob);
     
     

      alert("login successfull");
      {
        this.router.navigate(['Balance'])
      }

    }
    else{
      this.message1="Your account has been blocked";
      
    }
  }
      , error => { console.log(error),
        this.message1 = "invalid credentials";}
    )
  }
  else{
  
   
    this.loginservice.getUserAdmin(this.account.email, this.account.password).subscribe((data: any) => {
   
   this.admin=data;
   localStorage.setItem('isLoggedIn', "true");
   localStorage.setItem('isAdmin',"true");
   localStorage.setItem('email1',this.account.email);
  
   alert("login successfull");
   {
     this.router.navigate(['admin'])
   }

  } , error => { console.log(error),this.message1="invalid credentials"}
    )
  }
}
}