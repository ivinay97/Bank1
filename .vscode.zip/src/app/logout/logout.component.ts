import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';
import { AddcustomerService } from '../addcustomer.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private loginservice: AddcustomerService,
    private router: Router) { }

  ngOnInit() {
    this.loginservice.logout();

    this.router.navigate(['']);
  }
}