import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse,HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { account } from './account';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private url = 'http://localhost:8282'; 
  constructor() { }
  
  
}
