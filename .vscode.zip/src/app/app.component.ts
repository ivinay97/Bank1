import { Component } from '@angular/core';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { Routes } from '@angular/router';
import { BalanceComponent } from './balance/balance.component';
import { DebitComponent } from './debit/debit.component';
import { CreditComponent } from './credit/credit.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { TransactionComponent } from './transaction/transaction.component';
import { LogoutComponent } from './logout/logout.component';
import { LoginComponent } from './login/login.component';
import { AuthenticationService } from './authentication.service';
import { AuthguardService } from './authguard.service';
import { account } from './account';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { ProfileComponent } from './profile/profile.component';
import { AdminComponent } from './admin/admin.component';
import { Role } from './role.enum';
import { AdminAuthGuardService } from './admin-auth-guard.service';
import { UserTransactionsComponent } from './user-transactions/user-transactions.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  account: account = new account();
  title = 'Welcome To  Bank';
  model: any = {};
  constructor(private loginService: AuthguardService, private _service: AdminAuthGuardService) {
  }
}

export const routes: Routes = [{ path: 'Add', component: AddcustomerComponent },
{ path: 'Balance', component: BalanceComponent, canActivate: [AuthguardService] },
{ path: 'debit', component: DebitComponent, canActivate: [AuthguardService] },
{ path: 'credit', component: CreditComponent, canActivate: [AuthguardService] },
{ path: 'fundtransfer', component: FundtransferComponent, canActivate: [AuthguardService] },
{ path: 'transactions', component: TransactionComponent, canActivate: [AuthguardService] },
{ path: 'logout', component: LogoutComponent, canActivate: [AuthguardService] },
{ path: '', component: LoginComponent },
{ path: 'admin', component: AdminComponent, canActivate: [AdminAuthGuardService] },
{ path: 'user', component: UserTransactionsComponent, canActivate: [AdminAuthGuardService] },
{ path: 'change', component: ChangepasswordComponent, canActivate: [AuthguardService] },
{ path: 'profile', component: ProfileComponent, canActivate: [AuthguardService] }
];