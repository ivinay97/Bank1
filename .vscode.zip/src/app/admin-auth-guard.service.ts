import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthGuardService implements CanActivate{
  constructor(private router: Router) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    let url: string = state.url;
    return this.verifyLogin(url);
  }
  verifyLogin(url): boolean 
  {
    if (!this.isAdmin()) 
    {
      this.router.navigate(['']);
      return false;
    }
    else if (this.isAdmin()) 
    {
      return true;
    }
  }
  public isAdmin(): boolean
  {
    if((localStorage.getItem('isAdmin') == "true")&&(localStorage.getItem("isLoggedIn") == "true"))
    {
return true;
    }
    else 
    {
    return false;
    }
  }
}