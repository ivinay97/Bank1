import { Component, OnInit } from '@angular/core';
import { account } from '../account';
import { Admin } from '../admin';
import { Transactions } from '../transactions';
import { AddcustomerService } from '../addcustomer.service';
@Component({
  selector: 'app-user-transactions',
  templateUrl: './user-transactions.component.html',
  styleUrls: ['./user-transactions.component.css']
})
export class UserTransactionsComponent implements OnInit {
  accounts: account = new account();
  transactions: Transactions = new Transactions();
  admin: Admin = new Admin();
  constructor(private _service: AddcustomerService) { }
  ngOnInit() {
    this.admin.username = localStorage.getItem("email1");
    var x = document.getElementById("tab");
    x.style.display = "none";
  }
  getTransactions() {
    this._service.getTransactions(this.accounts.accnumber).subscribe((data: any) => { console.log(data), this.transactions = data }, error => console.log(error));
    var x = document.getElementById("tab");
    x.style.display = "block";
  }
}