import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { account } from './account';


@Injectable({
  providedIn: 'root'
})
export class AddcustomerService {
acc:account=new account();

  constructor(private http:HttpClient) { }
  private baseUrl = 'http://localhost:8282'; 
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json'
    })
  };

  getUser(email:string,password:string){
    const headers = new HttpHeaders({ Authorization: 'Basic ' + window.btoa(email+":"+password) });


    return this.http.get(`${this.baseUrl}/user/getUser/${email}/${password}`,{headers});
  }

  getUserAdmin(email:string,password:string){
    const headers = new HttpHeaders({ Authorization: 'Basic ' + window.btoa(email+":"+password) });
    return this.http.get(`${this.baseUrl}/Admin/adminlogin`,{headers});
  }
   addAccount(accObj:account){
    
     return this.http.post(`${this.baseUrl}` + `/create`, accObj);
   }
   showBalance(accNo:number){
     
    return this.http.get(`${this.baseUrl}/user/showbalance/${accNo}`);
   }
   depositAmount(accNumber:number,amount:number){
     
     return this.http.put(`${this.baseUrl}/user/deposit/${accNumber}/${amount}`,new HttpHeaders({'Content-Type': 'application/json'}));
   }
   withdrawAmount(accNumber:number,amount:number){
     return this.http.put(`${this.baseUrl}/user/withdraw/${accNumber}/${amount}`,new HttpHeaders({'Content-Type': 'application/json'}));
   }
   fundTransfer(senderAc:number,recieverAc:number,amount:number){
    return this.http.put(`${this.baseUrl}/user/fundtransfer/${senderAc}/${recieverAc}/${amount}`,new HttpHeaders({'Content-Type': 'application/json'}));
   }
   getTransactions(accNum:number){
     return this.http.get(`${this.baseUrl}/showtransactions/${accNum}`);
   }

   logout(): void {
     
    localStorage.clear();
    sessionStorage.clear();
    
      location.reload();   
  }
  
  changepassword(nPassword:string,cPassword:string,acno:any){
		return this.http.put(`${this.baseUrl}/user/resetpassword/${nPassword}/${cPassword}/${acno}`,new HttpHeaders({'Content-Type': 'application/json'}));
  }

  adminchangepassword(nPassword:string,cPassword:string,userID:any){
		return this.http.put(`${this.baseUrl}/Admin/resetpassword/${nPassword}/${cPassword}/${userID}`,new HttpHeaders({'Content-Type': 'application/json'}));
  }

  editProfile(accnumber:number,accholdername:string,branch:string,email:any,phonenumber:any,dob:any){
    return this.http.put(`${this.baseUrl}/user/editProfile/${accnumber}/${accholdername}/${branch}/${email}/${phonenumber}/${dob}`,new HttpHeaders({'Content-Type': 'application/json'}));
   
  }

  getAllUsers()
  {
    return this.http.get(`${this.baseUrl}/Admin/getAllUsers`);
  }

 block(acno:any)
 {
   return this.http.put(`${this.baseUrl}/Admin/blockuser/${acno}`,new HttpHeaders({'Content-Type': 'application/json'}));
 }
}