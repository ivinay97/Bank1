import { Component, OnInit } from '@angular/core';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  accounts: account = new account();
  constructor(private _service: AddcustomerService) { }

  ngOnInit() {
    this.accounts.accnumber = localStorage.getItem('email1');
    document.getElementById("Num").innerHTML = this.accounts.accnumber;
    this.accounts.accholdername = localStorage.getItem('acountname');
    document.getElementById("name").innerText = this.accounts.accholdername;
    this.accounts.branch = localStorage.getItem('branch');
    document.getElementById("address").innerText = this.accounts.branch;
    this.accounts.email = localStorage.getItem('email');
    document.getElementById("email").innerText = this.accounts.email;
    this.accounts.phonenumber = localStorage.getItem('phonenumber');
    document.getElementById("mobile").innerText = this.accounts.phonenumber;
    this.accounts.dob = localStorage.getItem('dob');
    document.getElementById("dob").innerText = this.accounts.dob;

  }

  display() {
    localStorage.setItem('acountname', this.accounts.accholdername);
    localStorage.setItem('branch', this.accounts.branch);
    localStorage.setItem('email', this.accounts.email);
    localStorage.setItem('phonenumber', this.accounts.phonenumber);
    localStorage.setItem('dob', this.accounts.dob);
    alert("profile changed successfully");
    {
      location.reload();
    }
  }
  editProfile() {
    return this._service.editProfile(this.accounts.accnumber, this.accounts.accholdername, this.accounts.branch, this.accounts.email, this.accounts.phonenumber, this.accounts.dob).subscribe((data: any) => {
      this.accounts = data, this.display(), console.log(this.accounts)
    }, error => console.log(error));
  }
}