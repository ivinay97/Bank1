import { Component, OnInit } from '@angular/core';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';

@Component({
  selector: 'app-credit',
  templateUrl: './credit.component.html',
  styleUrls: ['./credit.component.css']
})
export class CreditComponent implements OnInit 
{
    accounts:account=new account();
    constructor(private _service:AddcustomerService) { }

  ngOnInit() 
  {
    this.accounts.accnumber = localStorage.getItem("email1");
    document.getElementById("Num").innerHTML=this.accounts.accnumber;
  }
  displayText(num)
  {
    if (num==10) 
    {
        var x= document.getElementById("myDiv");
        x.style.display="none";
        alert("account doesnot exist");  
      {
      
        window.location.reload();  
        
      }
    } 
    else 
    {
      var x= document.getElementById("myDiv");
       x.style.display="block";
    }
  
  }
  depositAmount()
  {
    var x= document.getElementById("myDiv");
    x.style.display="none";
    this._service.depositAmount(this.accounts.accnumber,this.accounts.amount).subscribe((data:any)=>{this.accounts=data,this.displayText(0)},error=>this.displayText(10));  
  }
}