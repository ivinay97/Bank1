import { Component, OnInit } from '@angular/core';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';
import { Transactions } from '../transactions';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  count: number = 0;
  accounts: account = new account();
  transactions: Transactions = new Transactions();
  
  constructor(private _service: AddcustomerService) { }
  
 
  ngOnInit() {
    this.accounts.accnumber = localStorage.getItem("email1");
    this._service.getTransactions(this.accounts.accnumber).subscribe((data: any) => { this.transactions = data, this.displayText(0) }, error => this.displayText(10));
  }
  displayText(num) 
  {
    if (num == 10) {
      var x = document.getElementById("tab");
      x.style.display = "none";
      alert("account doesnot exist");
    } 
    else 
    {
      var x = document.getElementById("tab");
      x.style.display = "block";
    }
  }
}