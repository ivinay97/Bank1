package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.IProductDao;
import com.capg.model.Transactions;
import com.capg.model.Users;

@Service
public class ProductServiceImp implements IProductService {

	@Autowired
	IProductDao dao;
	@Override
	public Transactions generateInvoice() {
		return null;
	}

	@Override
	public Users registerUser(Users user) {
		// TODO Auto-generated method stub
		return dao.registerUser(user);
	}

	@Override
	public Users forgotPassword(String email) {
		// TODO Auto-generated method stub
		return dao.forgotPassword(email);
	}

	@Override
	public Users confirmUserAccount(String token) {
		// TODO Auto-generated method stub
		return dao.confirmationToken(token);
	}

	@Override
	public Users getUser(String email) {
		// TODO Auto-generated method stub
		return dao.getUser(email);
	}

	@Override
	public Users changePassword(String nPassword, String cPassword, String email) {
		// TODO Auto-generated method stub
		return dao.changePassword(nPassword,cPassword,email);
	}

}
