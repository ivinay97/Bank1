package com.capg.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.capg.model.Transactions;
import com.capg.model.Users;
import com.capg.service.EmailSenderService;
import com.capg.service.IProductService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ProductManagementContoller {
	
	@Autowired
	IProductService service;
	
	@Autowired
	private EmailSenderService emailService;
	
	Users users=new Users();
	
	@GetMapping(path = "", produces = "application/json")
	@ResponseBody
	public Transactions generateInvoice() {
		
		return null;
		
	}
	
	@PostMapping(path="/register")
	public Users registerUser(@RequestBody Users user) {
		return service.registerUser(user);
	}
	
	@GetMapping(path="/getUser/{email}/{password}")
	public Users getUser(@PathVariable String email,@PathVariable String password) {
		 Users user=service.getUser(email);
		 Users receiveUser=null;
		 if(user!=null) {
		 if(user.getEmail().equalsIgnoreCase(email) && user.getPassword().equalsIgnoreCase(password)) {
			 receiveUser=user;
		 }else  
		 {
			 receiveUser=null;
		 }}
		 return receiveUser;
		 
	}
	
	@GetMapping(path="/forgotpassword/{email}")
	public boolean forgotPassword(@PathVariable String email) {
		users = service.forgotPassword(email);
		boolean sentMail=false;
		if(users != null)
		{
			emailService.createEmailMessage(users.getEmail());
			emailService.sendEmail();
			sentMail=true;
		}else if(users==null) {
			sentMail=false;
		}
		
		return sentMail;
	}
	
	@GetMapping(path="/resetpassword/{nPassword}/{cPassword}")
	public boolean changePassword(@PathVariable String nPassword,@PathVariable String cPassword) {
		
		String email=users.getEmail();
		boolean changed;
		Users user=service.changePassword(nPassword,cPassword,email);
		if(user!=null) {
			changed=true;
		}else
		{
			changed=false;
		}
		return changed;
	}
	
	 @RequestMapping(value="register/{token}", method= {RequestMethod.GET, RequestMethod.POST})
	 public ModelAndView confirmUserAccount(@PathVariable String token)
     {
		 service.confirmUserAccount(token);
		 String url = "http://localhost:4200/";
		 return new ModelAndView("redirect:"+url);
     }
	
}
