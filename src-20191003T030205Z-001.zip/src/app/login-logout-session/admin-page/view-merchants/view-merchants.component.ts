import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-merchants',
  templateUrl: './view-merchants.component.html',
  styleUrls: ['./view-merchants.component.css']
})
export class ViewMerchantsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
