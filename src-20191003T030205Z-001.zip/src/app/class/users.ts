export class Users {
	name: string;
	email: string;
	phoneNumber: number;
	password: string;
	address : string;
	role : string;
	date_of_creation: Date;
	active: boolean;
	userId: number;
	shippingAddress:any;
	cart:any;
}