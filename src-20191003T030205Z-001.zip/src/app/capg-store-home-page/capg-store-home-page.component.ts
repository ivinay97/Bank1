import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-capg-store-home-page',
  templateUrl: './capg-store-home-page.component.html',
  styleUrls: ['./capg-store-home-page.component.css']
})
export class CapgStoreHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
