package com.capg.dao;

import org.springframework.data.repository.CrudRepository;

import com.capg.model.Bank;

public interface BankRepo extends CrudRepository<Bank, Long>{


	Bank findByEmail(String email);
}
