package com.capg.dao;

import org.springframework.data.repository.CrudRepository;

import com.capg.model.Admin;



public interface AdminRepo extends CrudRepository<Admin, String>{

		
}
