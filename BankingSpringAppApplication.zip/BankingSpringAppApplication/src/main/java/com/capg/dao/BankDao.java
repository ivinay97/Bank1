package com.capg.dao;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.Exception.AccountNotFound;
import com.capg.Exception.InSufficientBalanceException;
import com.capg.Exception.UserAlreadyExist;
import com.capg.model.Bank;
import com.capg.model.Transactions;
@Repository
public class BankDao implements IBankDao {
	@Autowired
	BankRepo bankRepo;
	@Autowired
	TransactionsRepo transRepo;
	@Override
	public Bank createAccount(Bank b) {
		Bank bank= bankRepo.findByEmail(b.getEmail().toLowerCase());
		
		if((bank==null)||(bank.getDob()!=b.getDob())&&((bank.getAccholdername().compareToIgnoreCase(b.getAccholdername())!=0)))
		{
		b.setAccnumber((long)(Math.random()*1000));
		b.setEmail(b.getEmail().toLowerCase());
		b.setFlag(false);
		b.setRole("user");
		bank = bankRepo.save(b);
		Transactions t = new Transactions();
		t.setTransactionId((long) (Math.random() * 1000));
		t.setCreditedAmount(b.getBalance());
		t.setDebitedAmount(0);
		t.setBalance(b.getBalance());
		t.setBank(b);
		t.setDateOfTransaction(new Date());
		transRepo.save(t);
		return bank;
	}
		else
		{
			throw new UserAlreadyExist(b);
		}
	}
	@Override
	public Bank showBalance(long accNo) {
		Bank b = bankRepo.findById(accNo).orElseThrow(() -> new AccountNotFound(accNo));
		return b;
	}
	@Override
	public Bank depositAmount(long accNumber, long depositedAmount) {
		Transactions t = new Transactions();
		Bank bank = bankRepo.findById(accNumber).orElseThrow(() -> new AccountNotFound(accNumber));
		long balance = bank.getBalance() + depositedAmount;
		bank.setBalance(balance);
		bank.setAccnumber(accNumber);
		t.setTransactionId((long) (Math.random() * 1000));
		t.setCreditedAmount(depositedAmount);
		t.setDebitedAmount(0);
		t.setBalance(balance);
		t.setBank(bank);
		t.setDateOfTransaction(new Date());
		Bank b = bankRepo.save(bank);
		
		transRepo.save(t);
		return b;
	}

	@Override
	public Bank withdrrawAmount(long accountNumber, long withdrawAmount) 
	{
		Transactions t = new Transactions();
		Bank bank = bankRepo.findById(accountNumber).orElseThrow(() -> new AccountNotFound(accountNumber));
		if(bank.getBalance()>withdrawAmount)
		{
		long balance = bank.getBalance() - withdrawAmount;
		bank.setBalance(balance);
		bank.setAccnumber(accountNumber);
		t.setTransactionId((long) (Math.random() * 1000));
		t.setCreditedAmount(0);
		t.setDebitedAmount(withdrawAmount);
		t.setBalance(balance);
		t.setBank(bank);
		t.setDateOfTransaction(new Date());
		transRepo.save(t);
		Bank b = bankRepo.save(bank);
		return b;
		}
		else
		{
			throw new InSufficientBalanceException(accountNumber);
		}
		
	}

	@Override
	public Bank fundTransfer(long senderAccNo, long recieverAccNo, long amount) {
		Bank b =withdrrawAmount(senderAccNo, amount);
		 depositAmount(recieverAccNo, amount);
		return b;
	}

	@Override
	public List<Transactions> printTransaction(long accouNum) {

		Bank b=bankRepo.findById(accouNum).orElseThrow(() -> new AccountNotFound(accouNum));
		
		List<Transactions> tlist=transRepo.findByBank(b);
		Collections.sort(tlist);
		
		
		return tlist;
		
	}

	@Override
	public Bank getBank(long accNum) {
		Optional<Bank> bank = bankRepo.findById(accNum);
		return bank.orElseThrow(() -> new AccountNotFound(accNum));
    }
	@Override
	public Bank getBank(String email,String password) {
		Bank bank= bankRepo.findByEmail(email.toLowerCase());
		if((bank!=null)&&(bank.getPassword().compareToIgnoreCase(password)==0)&&(bank.isFlag()==false))
		{
			return bank;	
		}
		else
			throw new AccountNotFound(email);
	}
	@Override
	public Bank changePassword(String password, long acno) {
		// TODO Auto-generated method stub
		Bank b=bankRepo.findById(acno).orElseThrow(() -> new AccountNotFound(acno));
		b.setPassword(password);
	     bankRepo.save(b);
		
		return b;
	}
	@Override
	public Bank editProfile(Bank b) {
		// TODO Auto-generated method stub
		long ac=b.getAccnumber();
        Bank bank=bankRepo.findById(ac).orElseThrow(() -> new AccountNotFound(ac));
        bank.setAccholdername(b.getAccholdername());
        bank.setBranch(b.getBranch());
        bank.setDob(b.getDob());
        bank.setEmail(b.getEmail().toLowerCase());
        bank.setPhonenumber(b.getPhonenumber());
        Bank b1=bankRepo.save(bank);
        
		return b1 ;
	}
	public List<Bank> getAllUsers(long acno)
	{
		Bank b= bankRepo.findById(acno).orElseThrow(() -> new AccountNotFound(acno));
		String role=b.getRole().toLowerCase();
		if(role.compareTo("admin")==0)
		{
	List<Bank> blist= (List<Bank>) bankRepo.findAll();
	
		return blist;
		}
		else
			throw new AccountNotFound(acno);
	}
	@Override
	public Bank block(long acno) {
		// TODO Auto-generated method stub
	Bank b=	bankRepo.findById(acno).orElseThrow(() -> new AccountNotFound(acno));
	if(b.isFlag()==false)
	  b.setFlag(true);
	else
		b.setFlag(false);
	  Bank b1=bankRepo.save(b);
	  System.out.println(b1.isFlag());
	return b1;
	}

}
