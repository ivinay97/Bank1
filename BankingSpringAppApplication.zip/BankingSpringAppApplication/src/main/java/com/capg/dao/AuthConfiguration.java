package com.capg.dao;

import org.springframework.context.annotation.Configuration;

@Configuration

public class AuthConfiguration {

}
