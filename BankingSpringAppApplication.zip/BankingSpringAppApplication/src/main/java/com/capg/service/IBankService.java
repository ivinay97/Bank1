package com.capg.service;

import java.util.List;

import com.capg.model.Bank;
import com.capg.model.Transactions;

public interface IBankService {
	public abstract Bank createAccount(Bank b);

	public abstract Bank showBalance(long accNo);

	public abstract Bank depositAmount(long accNumber, long depositedAmount);

	public abstract Bank withdrawAmount(long accountNumber, long withdrawAmount);

	public abstract Bank fundTransfer(long senderAccno, long recieverAccNo, long amount);

	public abstract List<Transactions> printTransactions(long accouNum);
	public abstract Bank getBank(long accNum);
	public abstract Bank getBank(String email,String password);
	public abstract Bank changePassword(String pwd,long acno );
	public abstract Bank editProfile(Bank b);
	public abstract List<Bank> getAllUsers(long acno);
	public abstract Bank block(long acno);

}
