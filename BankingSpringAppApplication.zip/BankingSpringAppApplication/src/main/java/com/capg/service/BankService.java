package com.capg.service;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capg.Exception.ValidateInputsException;
import com.capg.dao.IBankDao;
import com.capg.model.Bank;
import com.capg.model.Transactions;
@Service
public class BankService implements IBankService {
	@Autowired
	IBankDao dao;
	@Override
	public Bank createAccount(Bank b) {
		
		 CharSequence inputStr = b.getAccholdername();
		 CharSequence inputStr1 = b.getPhonenumber();
		    Pattern pattern = Pattern.compile(new String ("^[a-zA-Z\\s]*$"));
		    Pattern pattern1 = Pattern.compile(new String ("([1-9][0-9]{9})"));
		    Matcher matcher = pattern.matcher(inputStr);
		    Matcher matcher1 = pattern1.matcher(inputStr1);
		    if((matcher.matches())&&(matcher1.matches()))
		    {
		    	return dao.createAccount(b);
		    }
		    else
			{
				throw  new ValidateInputsException(b);
			    
			}
		
	}

	@Override
	public Bank showBalance(long accNo) {
          
		return dao.showBalance(accNo);
	}

	@Override
	public Bank depositAmount(long accNumber, long depositedAmount) {
		return dao.depositAmount(accNumber, depositedAmount);
	}

	@Override
	public Bank withdrawAmount(long accountNumber, long withdrawAmount) {
		return dao.withdrrawAmount(accountNumber, withdrawAmount);

	}

	@Override
	public Bank fundTransfer(long senderAccno, long recieverAccNo, long amount) {
		return dao.fundTransfer(senderAccno, recieverAccNo, amount);

	}

	@Override
	public List<Transactions> printTransactions(long accouNum) {

		return dao.printTransaction(accouNum);
	}

	@Override
	public Bank getBank(long accNum) {
	
		return dao.getBank(accNum);
	}

	@Override
	public Bank getBank(String email) {
		// TODO Auto-generated method stub
		return dao.getBank(email);
	}

	@Override
	public Bank changePassword(String pwd, long acno) {
		// TODO Auto-generated method stub
		return dao.changePassword(pwd, acno);
	}

	

}
