package com.capg.model;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name = "bank")
public class Bank {
	@Id
	private long accnumber;
	@NotNull(message = "Name is required")
	private String accholdername;
	@NotNull(message = "branch is required")
	private String branch;
	@NotNull(message="email is required")
	private String email;
	@NotNull(message = "Phone number is required")
	private String phonenumber;
	@NotNull(message = "Date of Birth is required")
	@DateTimeFormat(pattern="MM/dd/yyyy")
	private Date dob;
	@NotNull(message="password is required")
	private String password;
	
	private boolean flag;
	
	private String role;
	private long balance;
	@OneToMany(mappedBy = "bank", cascade = CascadeType.ALL)
	private Set<Transactions> transactions= new HashSet<Transactions>();

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}
	public Set<Transactions> getTransactions() {
		return transactions;
	}

	public void setTransactions(Set<Transactions> transactions) {
		this.transactions = transactions;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getAccnumber() {
		return accnumber;
	}

	public void setAccnumber(long accnumber) {
		this.accnumber = accnumber;
	}

	public String getAccholdername() {
		return accholdername;
	}

	public void setAccholdername(String accholdername) {
		this.accholdername = accholdername;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	

	

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "accnumber=" + accnumber + ", accholdername=" + accholdername + ", branch=" + branch + ", email="
				+ email + ", phonenumber=" + phonenumber + ", dob=" + dob + ", password=" + password + ", flag=" + flag
				+ ", role=" + role + ", balance=" + balance;
	}

	

	

	
	
	

	
	
}
