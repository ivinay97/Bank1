package com.capg.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.stereotype.Component;
@Component
@Entity
public class Transactions implements Comparable<Transactions>{
	@Id
	private long transactionId;
	private long creditedAmount;
	private long debitedAmount;
	private long balance;
	private Date dateOfTransaction; 
	@ManyToOne
	@JoinColumn(name = "accnumber")
	private Bank bank;	

	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public long getCreditedAmount() {
		return creditedAmount;
	}

	public void setCreditedAmount(long creditedAmount) {
		this.creditedAmount = creditedAmount;
	}

	public long getDebitedAmount() {
		return debitedAmount;
	}

	public void setDebitedAmount(long debitedAmount) {
		this.debitedAmount = debitedAmount;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}



	public void setBank(Bank bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", creditedAmount=" + creditedAmount
				+ ", debitedAmount=" + debitedAmount + ", balance=" + balance + ", dateOfTransaction="
				+ dateOfTransaction + ", AccNumber=" + bank.getAccnumber() + "]";
	}

	@Override
	public int compareTo(Transactions o) {
		// TODO Auto-generated method stub
		return 	o.getDateOfTransaction().compareTo(getDateOfTransaction());
		
	}

	


	



}
