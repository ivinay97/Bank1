package com.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.Exception.RequiredFieldException;
import com.capg.Exception.ValidateInputsException;
import com.capg.model.Bank;
import com.capg.model.Transactions;
import com.capg.service.IBankService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController()
public class AppController {
	@Autowired
	private IBankService service;

	@PostMapping(path = "/create", consumes = "application/json")
	public Bank home(@Valid @RequestBody Bank b) {
		
		return service.createAccount(b);
	}

	@GetMapping(path="/getUser/{email}/{password}")
	public Bank getUser(@PathVariable String email,@PathVariable String password) {
		
		Bank user=service.getBank(email);
		 Bank receiveUser=null;
		 if(user!=null) {
		 if(user.getEmail().equalsIgnoreCase(email) && user.getPassword().equalsIgnoreCase(password)) {
			 receiveUser=user;
		 }else  
		 {
			 receiveUser=null;
		 }}
		 return receiveUser;
		 
	}
	
	
	
	
	@GetMapping(path = "/showbalance/{accNo}", produces = "application/json")
	public Bank balance(@PathVariable long accNo) {
		
		return service.showBalance(accNo);
	}

	@GetMapping(path = "/bank/{accNo}", produces = "application/json")
	public Bank getBank(@PathVariable long accNo) {
		String s=Long.toString(accNo);
		if(((s == null) ||(s == " ")))
		{
			throw new RequiredFieldException(s);
		}
		else {
		return service.getBank(accNo);
	}
	}
	@PutMapping(path = "/deposit/{accNo}/{depositAmount}", consumes  = "application/json")
	public Bank depositAmount(@PathVariable long accNo,@PathVariable long depositAmount) {
		return service.depositAmount(accNo, depositAmount);
	}
	@PutMapping(path = "/withdraw/{accNo}/{withdrawAmount}", consumes  = "application/json")
	public Bank withdrawAmount(@PathVariable long accNo,@PathVariable long withdrawAmount) {
		return service.withdrawAmount(accNo, withdrawAmount);
	}
	@PutMapping(path = "/fundtransfer/{senderAccNo}/{recieverAccNo}/{amount}", consumes  = "application/json")
	public Bank fundtransfer(@PathVariable long senderAccNo,@PathVariable long recieverAccNo,@PathVariable long amount) {
		return service.fundTransfer(senderAccNo, recieverAccNo, amount);
	}
	@GetMapping(path = "/showtransactions/{accNo}", produces = "application/json")
	public List<Transactions> showTransaction(@PathVariable long accNo) {
		return service.printTransactions(accNo);
	}
	@GetMapping(path="/resetpassword/{password}/{cpassword}/{acno}",produces = "application/json")
	public Bank changePassword(@PathVariable String password,@PathVariable String cpassword,@PathVariable long acno) {
		Bank changed=null;
		int i= password.compareTo(cpassword);
		
		if(i==0)
		{
			
			changed=service.changePassword(password, acno);
			
	return changed;	
		}
		else
		{
			String message="password mismatch";
			throw new RequiredFieldException(message);
		}
}
}
