package com.capg.Exception;

public class InSufficientBalanceException extends RuntimeException {

	 public InSufficientBalanceException(Long id) {
	        super("Account "+ id +" have insufficient Balance" );
	    }
}
