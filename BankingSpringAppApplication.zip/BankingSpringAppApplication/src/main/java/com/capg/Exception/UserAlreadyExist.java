package com.capg.Exception;

import com.capg.model.Bank;

public class UserAlreadyExist extends RuntimeException {

	 public UserAlreadyExist(Bank b) {
	        super("Account already exist: " + b);
	    }
	
}
