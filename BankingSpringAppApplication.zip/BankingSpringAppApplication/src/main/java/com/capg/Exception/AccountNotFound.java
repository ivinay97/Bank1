package com.capg.Exception;

public class AccountNotFound extends RuntimeException{

	    public AccountNotFound(Long id) {
	        super("Account id not found : " + id);
	    }
	    public AccountNotFound(String msg)
	    {
	    	super("account not found");
	    }

	}
	


