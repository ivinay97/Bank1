package com.capg.Exception;

import com.capg.model.Bank;

public class ValidateInputsException extends RuntimeException {
	 public ValidateInputsException(Bank b) {
	        super("Check Inputs i.e, AccountName should contain only alphabets(blank space included), phone number should be 10 digits. Your input values are " + b);
	    }

}
