package com.capg.Exception;

public class RequiredFieldException extends RuntimeException {
     public RequiredFieldException(String mgs) {
    	 super("field is required"+mgs);

     }
}
