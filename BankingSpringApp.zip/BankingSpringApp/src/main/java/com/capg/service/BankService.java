package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.IBankDao;
import com.capg.model.Bank;
import com.capg.model.Transactions;

@Service
public class BankService implements IBankService {
	@Autowired
	IBankDao dao;

	@Override
	public Bank createAccount(Bank b) {
		return dao.createAccount(b);
	}

	@Override
	public Bank showBalance(long accNo) {

		return dao.showBalance(accNo);
	}

	@Override
	public Bank depositAmount(long accNumber, long depositedAmount) {
		return dao.depositAmount(accNumber, depositedAmount);
	}

	@Override
	public Bank withdrawAmount(long accountNumber, long withdrawAmount) {
		return dao.withdrrawAmount(accountNumber, withdrawAmount);

	}

	@Override
	public Bank fundTransfer(long senderAccno, long recieverAccNo, long amount) {
		return dao.fundTransfer(senderAccno, recieverAccNo, amount);

	}

	@Override
	public List<Transactions> printTransactions(long accouNum) {

		return dao.printTransaction(accouNum);
	}

	@Override
	public Bank getBank(long accNum) {
	
		return dao.getBank(accNum);
	}

}
