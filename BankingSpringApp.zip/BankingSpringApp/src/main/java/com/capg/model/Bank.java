package com.capg.model;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name = "bank")
public class Bank {
	@Id
	private long accnumber;
	private String accholdername;
	private String branch;
	private String phonenumber;
	private Date dob;
	private long balance;
	@OneToMany(mappedBy = "bank", cascade = CascadeType.ALL)
	private Set<Transactions> transactions= new HashSet<Transactions>();

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}
	public Set<Transactions> getTransactions() {
		return transactions;
	}

	public void setTransactions(Set<Transactions> transactions) {
		this.transactions = transactions;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getAccnumber() {
		return accnumber;
	}

	public void setAccnumber(long accnumber) {
		this.accnumber = accnumber;
	}

	public String getAccholdername() {
		return accholdername;
	}

	public void setAccholdername(String accholdername) {
		this.accholdername = accholdername;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	@Override
	public String toString() {
		return "Bank [accnumber=" + accnumber + ", accholdername=" + accholdername + ", branch=" + branch
				+ ", phonenumber=" + phonenumber + ", dob=" + dob + ", balance=" + balance + "]";
	}
}
