package com.capg.dao;

import java.util.List;

import com.capg.model.Bank;
import com.capg.model.Transactions;

public interface IBankDao {
	public abstract Bank createAccount(Bank b);

	public abstract Bank showBalance(long accNo);

	public abstract Bank depositAmount(long accNumber, long depositedAmount);

	public abstract Bank withdrrawAmount(long accountNumber, long withdrawAmount);

	public abstract Bank fundTransfer(long senderAccNo,long recieverAccNo, long balance);

	public abstract List<Transactions> printTransaction(long accouNum);
	public abstract Bank getBank(long accNum);

}
