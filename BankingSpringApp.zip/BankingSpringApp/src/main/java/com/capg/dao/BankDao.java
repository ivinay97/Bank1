package com.capg.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.model.Bank;
import com.capg.model.Transactions;

@Repository
public class BankDao implements IBankDao {
	@Autowired
	BankRepo bankRepo;
	@Autowired
	TransactionsRepo transRepo;

	@Override
	public Bank createAccount(Bank b) {
		b.setAccnumber((long)(Math.random()*1000));
		Bank bank = bankRepo.save(b);
		Transactions t = new Transactions();

		t.setTransactionId((long) (Math.random() * 1000));
		t.setCreditedAmount(b.getBalance());
		t.setDebitedAmount(0);
		t.setBalance(b.getBalance());
		t.setBank(b);
		t.setDateOfTransaction(new Date());
		transRepo.save(t);
		return bank;
	}

	@Override
	public Bank showBalance(long accNo) {
		Bank b = bankRepo.findById(accNo).orElse(null);
		return b;
	}

	@Override
	public Bank depositAmount(long accNumber, long depositedAmount) {
		Transactions t = new Transactions();
		Optional<Bank> bank = bankRepo.findById(accNumber);
		long balance = bank.get().getBalance() + depositedAmount;
		bank.get().setBalance(balance);
		bank.get().setAccnumber(accNumber);
		t.setTransactionId((long) (Math.random() * 1000));
		t.setCreditedAmount(depositedAmount);
		t.setDebitedAmount(0);
		t.setBalance(balance);
		t.setBank(bank.get());
		t.setDateOfTransaction(new Date());
		Bank b = bankRepo.save(bank.get());
		transRepo.save(t);
		return b;
	}

	@Override
	public Bank withdrrawAmount(long accountNumber, long withdrawAmount) {
		Transactions t = new Transactions();
		Optional<Bank> bank = bankRepo.findById(accountNumber);
		long balance = bank.get().getBalance() - withdrawAmount;
		bank.get().setBalance(balance);
		bank.get().setAccnumber(accountNumber);
		t.setTransactionId((long) (Math.random() * 1000));
		t.setCreditedAmount(0);
		t.setDebitedAmount(withdrawAmount);
		t.setBalance(balance);
		t.setBank(bank.get());
		t.setDateOfTransaction(new Date());
		transRepo.save(t);
		Bank b = bankRepo.save(bank.get());
		return b;
	}

	@Override
	public Bank fundTransfer(long senderAccNo, long recieverAccNo, long amount) {
		 withdrrawAmount(senderAccNo, amount);
		 Bank b =depositAmount(recieverAccNo, amount);
		return b;
	}

	@Override
	public List<Transactions> printTransaction(long accouNum) {

		Bank b=bankRepo.findById(accouNum).orElse(null);
		List<Transactions> tlist=transRepo.findByBank(b);
		return tlist;
		/*
		 * Bank b = bankRepo.findByAccnumber(accouNum).orElse(null); List<Transactions>
		 * t = new ArrayList<Transactions>(); List<Transactions> t2 = new
		 * ArrayList<Transactions>(); t = (List<Transactions>) transRepo.findAll();
		 * Iterator<Transactions> it1 = t.iterator(); while (it1.hasNext()) {
		 * Transactions t1 = it1.next(); if (t1.getBank() == b) { t2.add(t1); } }
		 * System.out.println(t2); return t2;
		 */
	}

	@Override
	public Bank getBank(long accNum) {
		Optional<Bank> bank = bankRepo.findById(accNum);
		return bank.orElse(null);
	}

}