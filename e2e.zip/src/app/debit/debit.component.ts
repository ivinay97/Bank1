import { Component, OnInit } from '@angular/core';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';

@Component({
  selector: 'app-debit',
  templateUrl: './debit.component.html',
  styleUrls: ['./debit.component.css']
})
export class DebitComponent implements OnInit {
accounts:account=new account();
  constructor(private _service:AddcustomerService) { }

  ngOnInit() {
  let x=sessionStorage.getItem("email1");
  
    document.getElementById("Num").innerHTML=x;
    this.accounts.accnumber = sessionStorage.getItem("email1");
   
  }
  displayText(num){
    if (num==10) {
      var x= document.getElementById("myDiv");
      x.style.display="none";
      alert("account doesnot exist or insufficient balance to withdraw");  
      {
        window.location.reload();
      }
    } else {
      var x= document.getElementById("myDiv");
      x.style.display="block";
      
    }
    
  }
  withdrawAmount(){
   
    var x= document.getElementById("myDiv");
    x.style.display="none";
 return   this._service.withdrawAmount(this.accounts.accnumber,this.accounts.amount).subscribe((data:any)=>{this.accounts=data,this.displayText(0)},error=>this.displayText(10));
 
  }
}
