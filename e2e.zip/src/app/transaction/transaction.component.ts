import { Component, OnInit } from '@angular/core';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';
import { Transactions } from '../transactions';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
accounts:account=new account();
transactions:Transactions=new Transactions();
  constructor(private _service:AddcustomerService) { }
  columns = [{
    datetrans: this.transactions.dateOfTransaction
  }];
  ngOnInit() {
    this.accounts.accnumber = sessionStorage.getItem("email1");
  }
  displayText(num){
    if (num==10) {
      var x= document.getElementById("tab");
      x.style.display="none";
      alert("account doesnot exist");  
    
    } else {
      var x= document.getElementById("tab");
      x.style.display="block";
    }
    

}

  


  
  



  getTransactions(){
   
    return this._service.getTransactions(this.accounts.accnumber).subscribe((data:any)=>{console.log(data),this.transactions=data.transactions,this.displayText(0)},error=>this.displayText(10));
  }
}
