import { Component, OnInit } from '@angular/core';
import { AddcustomerService } from '../addcustomer.service';
import { account } from '../account';

@Component({
  selector: 'app-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.css']
})
export class BalanceComponent implements OnInit {
accounts:account= new account
  constructor(private _service:AddcustomerService) { }

  ngOnInit() {
    this.accounts.accnumber = localStorage.getItem("email1");
    let accNo={accnumber:this.accounts.accnumber};
  
  var x= document.getElementById("myDiv");
  x.style.display="none";
  return this._service.showBalance(accNo.accnumber).subscribe((data:any)=>{this.accounts=data,this.displayText(0)},error=>this.displayText(10));
   
  }
  displayText(num){
    if (num==10) {
      var x= document.getElementById("myDiv");
      x.style.display="none";
      alert("account doesnot exist");  
    } else {
      var x= document.getElementById("myDiv");
      x.style.display="block";
    }
    
  }


}
