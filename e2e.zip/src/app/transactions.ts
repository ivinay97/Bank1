export class Transactions{
    transactionsId:number;
    creditedAmount:number;
    debitedAmount:number;
    balance:number;
    dateOfTransaction:any;
}