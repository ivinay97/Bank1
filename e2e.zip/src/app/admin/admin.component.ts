import { Component, OnInit } from '@angular/core';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
 admin:any
 accounts:account= new account();
 account:account=new account();
  constructor(private _service:AddcustomerService) { }

  ngOnInit() {
 this.admin=  localStorage.getItem("email1");
  this._service.getAllUsers(this.admin).subscribe((data:any)=>{this.accounts=data},error=>console.log(error));
  


  }
  
 block(ac:account)
 {
  this._service.block(ac.accnumber).subscribe((data: any) =>{ 
    this.account = data,
  
    alert(this.account.accnumber);
    if(this.account.flag)
    {
      alert("blocked successfully");
      {
     document.getElementById(this.account.accnumber).innerText="BLOCKED"
    
      }
    }
    else
    {
      alert("unblocked unsuccessfully");
      {
      document.getElementById(this.account.accnumber).innerText="BLOCK"
      
      
    }
    }
  
  
  
  },error=>console.log(error));
  }
 
}

