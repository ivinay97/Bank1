import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';
import { AuthguardService } from '../authguard.service';
import{Role} from '../role.enum';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  account: account = new account();
  constructor(private router: Router,
    private loginservice: AddcustomerService,private guard: AuthguardService) { }
  message: string = "";
  message1: string = "";
  
  conversionOutput: string;
  ngOnInit() {
  let x = this.guard.isLoggedIn();
  
  if(x)
  {
    this.router.navigate(['Balance']);
  }
  else
  {
    this.router.navigate(['']);
  }
  }

  checkLogin() {
    this.loginservice.getUser(this.account.email, this.account.password).subscribe((data: any) => {
      this.account = data;
      sessionStorage.setItem('isLoggedIn', "true");
      localStorage.setItem('isLoggedIn',"true");
      if(this.account.role === Role.Admin)
      {
         localStorage.setItem('isAdmin',"true");
      }
      else
      {
        localStorage.setItem('isAdmin',"false");
      }
     sessionStorage.setItem('email1',this.account.accnumber);
    
      localStorage.setItem('email1',this.account.accnumber);
      sessionStorage.setItem('acountname', this.account.accholdername);
     localStorage.setItem('acountname', this.account.accholdername);
      localStorage.setItem('branch',this.account.branch);
      localStorage.setItem('email',this.account.email);
      localStorage.setItem('phonenumber',this.account.phonenumber);
      localStorage.setItem('dob',this.account.dob);
     
     

      alert("login successfull");
      {
        this.router.navigate(['Balance'])
      }

    }
      , error => { console.log(error), this.display()  }
    )
  }
  display(){
if(!this.account.flag)
{
  this.message1 = "Your account has been locked by Bank" ; 
}
else
this.message1 = "invalid credentials";
  }

}
