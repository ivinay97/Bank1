import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  account: account = new account();
  constructor(private router: Router,
    private loginservice: AddcustomerService) { }
  message: string = "";
  message1: string = "";
  ngOnInit() {
    this.loginservice.logout();
  }

  checkLogin() {
    this.loginservice.getUser(this.account.email, this.account.password).subscribe((data: any) => {
      this.account = data;
      sessionStorage.setItem('isLoggedIn', "true");
      
      
      
     sessionStorage.setItem('email1',this.account.accnumber);
      
      sessionStorage.setItem('acountname', this.account.accholdername);
      sessionStorage.setItem('branch',this.account.branch);
      sessionStorage.setItem('email',this.account.email);
      sessionStorage.setItem('phonenumber',this.account.phonenumber);
      sessionStorage.setItem('dob',this.account.dob);
     
     

      alert("login successfull");
      {
        this.router.navigate(['Balance'])
      }

    }
      , error => { console.log(error), this.message1 = "invalid credentials" }
    )
  }
  display():any{
return  sessionStorage.setItem('email1',this.account.accnumber);
  }

}
