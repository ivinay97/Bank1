import { Component, OnInit } from '@angular/core';
import { account } from '../account';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
account:account=new account();
  constructor() { }

  ngOnInit() {
   this.account.accnumber = sessionStorage.setItem('email1',this.account.accnumber);
  this.account.accholdername =  sessionStorage.setItem('acountname', this.account.accholdername);
 this.account.branch =  sessionStorage.setItem('branch',this.account.branch);
  this.account.email = sessionStorage.setItem('email',this.account.email);
 this.account.phonenumber  = sessionStorage.setItem('phonenumber',this.account.phonenumber);
  this.account.dob = sessionStorage.setItem('dob',this.account.dob);
  }

}
