import { Component, OnInit } from '@angular/core';
import { AddcustomerService } from '../addcustomer.service';
import { NgForm } from '@angular/forms';
import { account } from '../account';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.css']
})
export class AddcustomerComponent implements OnInit {
accounts:account=new account();
  constructor(private _service:AddcustomerService,private router: Router,) { }


display(){
  alert("your account number is" +this.accounts.accnumber)
  {
    this.router.navigate(['login'])
  }
}


  addAccount(){
    if (this.accounts.accholdername == undefined) {/*branch:this.accounts.branch,phonenumber:this.accounts.phonenumber,dob:this.accounts.dob,balance:this.accounts.balance*/
      var x= document.getElementById("myName");
      x.style.display="block";
    } else {
      
      let accObj={accholdername:this.accounts.accholdername,branch:this.accounts.branch,email:this.accounts.email,phonenumber:this.accounts.phonenumber,dob:this.accounts.dob,password:this.accounts.password,balance:this.accounts.balance};
 
      this._service.addAccount(this.accounts).subscribe((data:any)=>{this.accounts=data, this.display(),console.log(this.accounts)
      }, error=>{console.log(error),alert("account already exist")});
     
    }

   
  }

  ngOnInit() {
    
  }

}
