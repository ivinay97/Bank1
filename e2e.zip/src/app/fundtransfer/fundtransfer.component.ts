import { Component, OnInit } from '@angular/core';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';

@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {
accounts:account=new account();
  constructor(private _service:AddcustomerService) { }

  ngOnInit() {
    this.accounts.senderAccNumber =localStorage.getItem("email1");
  }
 
displayText(num){
  if(num==10)
  {
    
    
   
      alert("insufficent balance in your account or  given account doesnot exist");
      {
      window.location.reload();  
      }
  }
  else 
  {
    
    alert("Amount has been transfered successfully")
    {
    window.location.reload(); 
  }
}
}



  fundTransfer(){
    if(this.accounts.senderAccNumber==this.accounts.recieverAccNumber)
    {
      alert("receiver account number cannot be your account number")
    }
    else
    {
   this._service.fundTransfer(this.accounts.senderAccNumber,this.accounts.recieverAccNumber,this.accounts.amount).subscribe((data:any)=>{this.accounts=data,this.displayText(0)},error=>{console.log(error),this.displayText(10)});
    }
  }
}
