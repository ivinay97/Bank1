import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { account } from '../account';
import { AddcustomerService } from '../addcustomer.service';
@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  
  message1:string;
  message:string;
  account:account=new account();
  constructor(private _service:AddcustomerService) { }

  ngOnInit() {
    this.account.accnumber=localStorage.getItem("email1");
    
  }
  display(){
 alert("password changed successfully")
 {
  location.reload();
 }


  }
  onSubmit()
  {
    
    
       this._service.changepassword(this.account.password,this.account.cpassword,this.account.accnumber).subscribe((data:any)=>{
        this.account=data,this.display()
       },error=>{console.error(),alert("Password in both the fields should match")})
           
       
     
    
    
      
    
  }
}
